t = 0:.1:5;
x1 = exp(-6*t)/42 - exp(t)/7 + 1/6;
x2 = exp(-6*t)/7 + exp(t)/7 + 0;
plot(t,x1,t,x2);